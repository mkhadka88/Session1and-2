import java.util.Scanner;

public class Factorialnumber {
public static void main(String args[]) {
	
	Scanner scan = new Scanner(System.in);
	
	System.out.println("Enter a number:");
	
	int i = scan.nextInt();
	
	int fact =1;
	for (i =0; i <=1; i++) {
		
		fact = fact*1;
		System.out.println("Factorial number is " + fact);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}
