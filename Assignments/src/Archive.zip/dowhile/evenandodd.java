package dowhile;

public class evenandodd {
public static void main(String args[]) {
	int i = 0;
	System.out.println("Even numbers is:");
	 i = 0;
	 do {
	 System.out.println(i);
	 i = i+2;
	 

	 }while (i< 20) ;
	 
	 System.out.println("Odd numbers is:");
	 i =1;
	 do {
	 System.out.println(i);
		i = i+2;
		
	 
	 }while (i<20);
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}
