import java.util.Scanner;

public class Tableoften {
public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter a number:");
			
	int x = sc.nextInt();
	
	for (int i =1; i < 11; i++) {
		System.out.println(x +"* " + i +" = "+ i *x);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}
