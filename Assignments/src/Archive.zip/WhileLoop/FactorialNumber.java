package WhileLoop;

import java.util.Scanner;

public class FactorialNumber {
public static void main(String args[]) {
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter a number:");
	
	int x = sc.hashCode();
	
	int fact = 1;
	int i =1;
	while(i<=x) {
		fact = fact *i;
		i++;
		
	}
	System.out.println("Factorial of a number is " + fact);
	
	
	
	
	
}
}
