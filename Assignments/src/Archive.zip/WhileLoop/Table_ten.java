package WhileLoop;

import java.util.Scanner;

public class Table_ten {
public static void main(String args[]) {
	
	Scanner scan = new Scanner (System.in);
	
	System.out.println("Enter a number:");
	int x = scan.nextInt();

	int i = 1;
	
	while (i<11) {
		System.out.println(i +"*" + x +" = " +x *i);
		i++;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}
