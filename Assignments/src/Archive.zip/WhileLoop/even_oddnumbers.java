package WhileLoop;

public class even_oddnumbers {
public static void main (String args[]) {
	int i = 0;
	
		System.out.println("Even number is:");
		
		while (i<20) {
			System.out.println(i);
			i= i + 2;
		}
		
		System.out.println("Odd number is:");
		i = 1;
		while (i< 20) {
			System.out.println(i);
		i = i+2;
		
		}
}
}