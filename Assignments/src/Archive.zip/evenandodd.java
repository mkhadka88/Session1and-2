
public class evenandodd {
public static void main(String args[]) {
	
	int i = 0;
	
	System.out.println("Even nummber is:");
	
	for (i = 0; i < 20; i = i + 2) {
		System.out.println(i);
	}
	
	System.out.println("Odd number is:");
	for ( i = 1; i < 20 ; i = i + 2) {
		System.out.println(i);
	}
	
}
}
