import java.util.Scanner;

public class postiveornegative {

	public static void main(String[] args) {
		int n = -5;

		if (n > 0) {
			System.out.println("It is positive");
		}

		else if (n < 0) {
			System.out.println("It is negative");
		}

	}

}
